#pragma once

#include <memory>
#include <string>
#include <vector>

#include <esp_err.h>
#include <esp_partition.h>
#include <esp_vfs_fat.h>
#include <sdmmc_cmd.h>

#include <driver/gpio.h>
#include <driver/i2s_std.h>
#include <driver/spi_master.h>
#include <hal/spi_ll.h>
#include <hal/spi_types.h>

#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <freertos/stream_buffer.h>
#include <freertos/task.h>

#include "base_component.hpp"
#include "es7210.hpp"
#include "gps.hpp"
#include "gt911.hpp"
#include "i2c.hpp"
#include "interrupt.hpp"
#include "led.hpp"
#include "pointer_input.hpp"
#include "sdcard.hpp"
#include "spi.hpp"
#include "st7789.hpp"
#include "sx126x.hpp"
#include "t_keyboard.hpp"
#include "touchpad_input.hpp"

namespace espp {
/// The TDeck class provides an interface to the LilyGo T-Deck ESP32-S3
/// development board.
///
/// The class provides access to the following features:
/// - Touchpad
/// - Display
/// - Keyboard
/// - Audio
/// - Interrupts
/// - I2C
/// - microSD (uSD) card
/// - LoRa radio (SX1262)
/// - GPS (T-Deck Plus only)
///
/// For more information, see
/// https://github.com/Xinyuan-LilyGO/T-Deck/tree/master and
/// https://github.com/Xinyuan-LilyGO/T-Deck/blob/master/examples/UnitTest/utilities.h
///
/// \note The keyboard has a backlight, which you can control with the shortcut
///       <tt>alt + b</tt>. The keyboard backlight is off by default.
///
/// The class is a singleton and can be accessed using the get() method.
///
/// \section t_deck_example Example
/// \snippet t_deck_example.cpp t-deck example
class TDeck : public BaseComponent {
public:
  /// Alias for the button callback function
  using button_callback_t = espp::Interrupt::event_callback_fn;

  /// Alias for the pixel type used by the TDeck display
  using Pixel = lv_color16_t;

  /// Alias for the display driver used by the TDeck
  using DisplayDriver = espp::St7789;

  /// Maximum number of bytes that can be transferred in a single SPI
  /// transaction to the Display. 32k on the ESP32-S3.
  static constexpr size_t SPI_MAX_TRANSFER_BYTES = SPI_LL_DMA_MAX_BIT_LEN / 8;

  /// Alias for the keypress callback for keyboard keypresses.
  using keypress_callback_t = TKeyboard::key_cb_fn;

  /// Alias for the touchpad data used by the TDeck touchpad
  using TouchpadData = espp::TouchpadData;

  /// Alias for the touch callback when touch events are received
  using touch_callback_t = std::function<void(const TouchpadData &)>;

  /// Alias for the pointer data used by the TDeck trackball
  using PointerData = espp::PointerData;

  /// Alias for the callback used to inform the user code of new trackball data.
  using trackball_callback_t = std::function<void(const PointerData &)>;

  /// Mount point for the uSD card on the TDeck.
  static constexpr char mount_point[] = "/sdcard";

  /// @brief Access the singleton instance of the TDeck class
  /// @return Reference to the singleton instance of the TDeck class
  static TDeck &get() {
    static TDeck instance;
    return instance;
  }

  TDeck(const TDeck &) = delete;
  TDeck &operator=(const TDeck &) = delete;
  TDeck(TDeck &&) = delete;
  TDeck &operator=(TDeck &&) = delete;

  /// Get a reference to the internal I2C bus
  /// \return A reference to the internal I2C bus
  /// \note The internal I2C bus is used for the touchscreen
  I2c &internal_i2c() { return internal_i2c_; }

  /// Get a reference to the interrupts
  /// \return A reference to the interrupts
  espp::Interrupt &interrupts() { return interrupts_; }

  /// Get the GPIO pin for the peripheral power
  /// \return The GPIO pin for the peripheral power
  /// \note This pin is used to enable/disable power to the peripherals, such as
  ///       the keyboard, screen, etc.
  static constexpr auto peripheral_power_pin() { return peripheral_power_pin_; }

  /// Enable or disable power to the peripherals
  /// \param on Whether to enable or disable power to the peripherals
  void peripheral_power(bool on);

  /// Get the state of the peripheral power
  /// \return true if power is enabled, false otherwise
  bool peripheral_power() const;

  /////////////////////////////////////////////////////////////////////////////
  // uSD Card
  /////////////////////////////////////////////////////////////////////////////

  /// Configuration for the uSD card
  struct SdCardConfig {
    bool format_if_mount_failed = false;    ///< Format the uSD card if mount failed
    int max_files = 5;                      ///< The maximum number of files to open at once
    size_t allocation_unit_size = 2 * 1024; ///< The allocation unit size in bytes
  };

  /// Initialize the uSD card
  /// \param config The configuration for the uSD card
  /// \return True if the uSD card was initialized properly.
  bool initialize_sdcard(const SdCardConfig &config);

  /// Get the uSD card
  /// \return A pointer to the uSD card
  /// \note nullptr until initialize_sdcard() succeeded. The card stays valid while
  ///       its volume is unmounted (sdcard_component()->unmount()), e.g. to hand it
  ///       to a USB host through espp::UsbDevice's MSC function.
  sdmmc_card_t *sdcard() const { return sdcard_ ? sdcard_->card() : nullptr; }

  /// Get the SD card component: mount() / unmount() (e.g. to hand the card to a
  /// USB host with the usb_device MSC function), format(), card_info(),
  /// volume_info(), ...
  /// \return The component, or nullptr until initialize_sdcard() succeeded
  espp::SdCard *sdcard_component() const { return sdcard_.get(); }

  /////////////////////////////////////////////////////////////////////////////
  // LoRa Radio (SX1262, HPD16A module)
  /////////////////////////////////////////////////////////////////////////////

  /// Initialize the LoRa radio (SX1262)
  /// \param radio_config The radio (modem) configuration to apply
  /// \return True if the radio was initialized properly
  /// \note The radio shares the SPI bus with the display and uSD card.
  /// \note The radio's DIO1 interrupt is automatically serviced via the
  ///       board's interrupt handler, so packets are delivered through the
  ///       callbacks registered on the returned driver (see
  ///       espp::Sx126x::set_receive_callback and friends).
  /// \note The radio's reset line (GPIO 17) is also routed to the T-Deck's
  ///       PDM digital-microphone clock / ES7210 interrupt line. The espp
  ///       microphone path (the ES7210 array) uses a different set of pins, so
  ///       the radio and microphone can be used together; only a PDM
  ///       microphone (which would drive GPIO 17) would conflict.
  bool initialize_lora(const Sx126x::RadioConfig &radio_config = {});

  /// Get the LoRa radio
  /// \return A shared pointer to the LoRa radio driver
  /// \note The radio is only available if initialize_lora() succeeded
  std::shared_ptr<Sx126x> lora() const { return lora_; }

  /// Get the GPIO pin for the LoRa radio chip select
  /// \return The GPIO pin for the LoRa radio chip select
  static constexpr auto lora_cs_gpio() { return lora_cs_io; }

  /// Get the GPIO pin for the LoRa radio DIO1 (interrupt) line
  /// \return The GPIO pin for the LoRa radio DIO1 line
  static constexpr auto lora_dio1_gpio() { return lora_dio1_io; }

  /// Get the GPIO pin for the LoRa radio BUSY line
  /// \return The GPIO pin for the LoRa radio BUSY line
  static constexpr auto lora_busy_gpio() { return lora_busy_io; }

  /// Get the GPIO pin for the LoRa radio reset line
  /// \return The GPIO pin for the LoRa radio reset line
  static constexpr auto lora_reset_gpio() { return lora_reset_io; }

  /////////////////////////////////////////////////////////////////////////////
  // GPS (T-Deck Plus only, u-blox MIA-M10Q)
  /////////////////////////////////////////////////////////////////////////////

  /// Initialize the GPS (T-Deck Plus only)
  /// \param fix_cb Optional callback invoked on each fix update
  /// \param baud_rate The baud rate of the GPS UART (9600 by default)
  /// \return True if the GPS was initialized properly
  /// \note The GPS UART pins are routed to the Grove connector on the base
  ///       T-Deck; on the T-Deck Plus they connect to the internal u-blox
  ///       MIA-M10Q receiver.
  bool initialize_gps(const Gps::fix_callback_fn &fix_cb = nullptr, uint32_t baud_rate = 9600);

  /// Get the GPS
  /// \return A shared pointer to the GPS driver
  /// \note The GPS is only available if initialize_gps() succeeded
  std::shared_ptr<Gps> gps() const { return gps_; }

  /// Get the GPIO pin for the GPS UART TX (ESP32 -> GPS)
  /// \return The GPIO pin for the GPS UART TX
  static constexpr auto gps_tx_gpio() { return gps_tx_io; }

  /// Get the GPIO pin for the GPS UART RX (GPS -> ESP32)
  /// \return The GPIO pin for the GPS UART RX
  static constexpr auto gps_rx_gpio() { return gps_rx_io; }

  /////////////////////////////////////////////////////////////////////////////
  // Keyboard
  /////////////////////////////////////////////////////////////////////////////

  /// Initialize the keyboard
  /// \param start_task Whether to start the keyboard task
  /// \param key_cb The key callback function, called when a key is pressed if
  ///         not null and the keyboard task is started
  /// \param poll_interval The interval at which to poll the keyboard
  /// \return true if the keyboard was successfully initialized, false otherwise
  /// \note The Keyboard has an interrupt pin connected from it (the esp32c3) to
  ///       the main esp32s3. However, the default firmware on the keyboard
  ///       (esp32c3) does not use this interrupt pin. Instead, the main esp32s3
  ///       must poll the keyboard to get key presses. This is done by the
  ///       keyboard task. If you update the firmware on the keyboard to use the
  ///       interrupt pin, you can set start_task to false and wire up the
  ///       interrupt to the keyboard()->read_key() method.
  /// \see TKeyboard
  /// \see keyboard()
  bool initialize_keyboard(bool start_task = true, const keypress_callback_t &key_cb = nullptr,
                           std::chrono::milliseconds poll_interval = std::chrono::milliseconds(10));

  /// Get the keyboard
  /// \return A shared pointer to the keyboard
  /// \note The keyboard is only available if it was successfully initialized
  std::shared_ptr<TKeyboard> keyboard() const;

  /// Get the GPIO pin for the keyboard interrupt
  /// \return The GPIO pin for the keyboard interrupt
  /// \note This pin is used to detect when a key is pressed on the keyboard
  ///       and is connected to the main esp32s3, however the default firmware
  ///       on the keyboard does not use this pin
  static constexpr auto keyboard_interrupt() { return keyboard_interrupt_io; }

  /////////////////////////////////////////////////////////////////////////////
  // Trackball
  /////////////////////////////////////////////////////////////////////////////

  /// Initialize the trackball
  /// \param trackball_cb The trackball callback function, called when the
  ///        trackball is moved if not null
  /// \param sensitivity The sensitivity of the trackball. The higher the
  ///        sensitivity, the faster the trackball will move
  /// \return true if the trackball was successfully initialized, false
  ///         otherwise
  /// \see trackball()
  /// \see trackball_data()
  /// \see trackball_read()
  /// \see set_trackball_sensitivity()
  /// \param enable_center_button Whether to configure the trackball's center
  ///        (click) button on GPIO0. Set this to false when the microphone is
  ///        in use: per LilyGO's documentation GPIO0 is not available while the
  ///        microphone is enabled, and leaving the button interrupt configured
  ///        on GPIO0 while recording produces a burst of spurious interrupts
  ///        that jitters the real-time audio capture. The four directional
  ///        quadrature pins are unaffected and still work.
  bool initialize_trackball(const trackball_callback_t &trackball_cb = nullptr,
                            int sensitivity = 10, bool enable_center_button = true);

  /// Get the trackball
  /// \return A shared pointer to the trackball
  /// \note The trackball is only available if it was successfully initialized
  /// \see initialize_trackball()
  /// \see trackball_data()
  /// \see trackball_read()
  /// \note This is the same as the pointer_input() method
  std::shared_ptr<PointerInput> trackball() const;

  /// Set the trackball sensitivity
  /// \param sensitivity The sensitivity of the trackball. The higher the
  ///       sensitivity, the faster the trackball will move
  /// \note The sensitivity can be negative, which will invert the direction of
  ///       the trackball
  void set_trackball_sensitivity(int sensitivity);

  /// Get the pointer input for the trackball
  /// \return A shared pointer to the pointer input for the trackball
  std::shared_ptr<PointerInput> pointer_input() const;

  /// Get the GPIO pin for the trackball up button
  /// \return The GPIO pin for the trackball up button
  static constexpr auto trackball_up_gpio() { return trackball_up; }

  /// Get the GPIO pin for the trackball down button
  /// \return The GPIO pin for the trackball down button
  static constexpr auto trackball_down_gpio() { return trackball_down; }

  /// Get the GPIO pin for the trackball left button
  /// \return The GPIO pin for the trackball left button
  static constexpr auto trackball_left_gpio() { return trackball_left; }

  /// Get the GPIO pin for the trackball right button
  /// \return The GPIO pin for the trackball right button
  static constexpr auto trackball_right_gpio() { return trackball_right; }

  /// Get the GPIO pin for the trackball button
  /// \return The GPIO pin for the trackball button
  static constexpr auto trackball_btn_gpio() { return trackball_btn; }

  /// Get the most recent trackball data
  /// \return The trackball data
  PointerData trackball_data() const;

  /// Get the most recent trackball data
  /// \param x The x coordinate
  /// \param y The y coordinate
  /// \param left_pressed Whether the left button is pressed
  /// \param right_pressed Whether the right button is pressed
  /// \note This method is a convenience method for integrating with LVGL, the
  ///      data it returns is identical to the data returned by the
  ///      trackball_data() method
  void trackball_read(int &x, int &y, bool &left_pressed, bool &right_pressed);

  /////////////////////////////////////////////////////////////////////////////
  // Touchpad
  /////////////////////////////////////////////////////////////////////////////

  /// Initialize the touchpad
  /// \param touch_cb The touch callback function, called when the touchpad is
  ///        touched if not null
  /// \return true if the touchpad was successfully initialized, false otherwise
  /// \note This will configure the touchpad interrupt pin which will
  ///       automatically call the touch callback function when the touchpad is
  ///       touched
  /// \note This can be called even if you have not initialized the display or
  ///       the LCD.
  bool initialize_touch(const touch_callback_t &touch_cb = nullptr);

  /// Get the touchpad input
  /// \return A shared pointer to the touchpad input
  std::shared_ptr<TouchpadInput> touchpad_input() const;

  /// Get the most recent touchpad data
  /// \return The touchpad data
  TouchpadData touchpad_data() const;

  /// Get the most recent touchpad data
  /// \param num_touch_points The number of touch points
  /// \param x The x coordinate
  /// \param y The y coordinate
  /// \param btn_state The button state (0 = button released, 1 = button pressed)
  /// \note This method is a convenience method for integrating with LVGL, the
  ///       data it returns is identical to the data returned by the
  ///       touchpad_data() method
  /// \see touchpad_data()
  void touchpad_read(uint8_t *num_touch_points, uint16_t *x, uint16_t *y, uint8_t *btn_state);

  /// Convert touchpad data from raw reading to display coordinates
  /// \param data The touchpad data to convert
  /// \return The converted touchpad data
  /// \note Uses the touch_invert_x and touch_invert_y settings to determine
  ///       if the x and y coordinates should be inverted
  TouchpadData touchpad_convert(const TouchpadData &data) const;

  /////////////////////////////////////////////////////////////////////////////
  // Display
  /////////////////////////////////////////////////////////////////////////////

  /// Initialize the LCD (low level display driver)
  /// \return true if the LCD was successfully initialized, false otherwise
  bool initialize_lcd();

  /// Initialize the display (lvgl display driver)
  /// \param pixel_buffer_size The size of the pixel buffer
  /// \return true if the display was successfully initialized, false otherwise
  /// \note This will also allocate two full frame buffers in the SPIRAM
  bool initialize_display(size_t pixel_buffer_size);

  /// Get the width of the LCD in pixels
  /// \return The width of the LCD in pixels
  static constexpr size_t lcd_width() { return lcd_width_; }

  /// Get the height of the LCD in pixels
  /// \return The height of the LCD in pixels
  static constexpr size_t lcd_height() { return lcd_height_; }

  /// Get the GPIO pin for the LCD data/command signal
  /// \return The GPIO pin for the LCD data/command signal
  static constexpr auto get_lcd_dc_gpio() { return lcd_dc_io; }

  /// Get the display width in pixels
  /// \return The display width in pixels
  static constexpr size_t display_width() { return lcd_width_; }

  /// Get the display height in pixels
  /// \return The display height in pixels
  static constexpr size_t display_height() { return lcd_height_; }

  /// Get the display width in pixels, according to the current orientation
  /// \return The display width in pixels, according to the current orientation
  size_t rotated_display_width() const;

  /// Get the display height in pixels, according to the current orientation
  /// \return The display height in pixels, according to the current orientation
  size_t rotated_display_height() const;

  /// Get a shared pointer to the display
  /// \return A shared pointer to the display
  std::shared_ptr<Display<Pixel>> display() const;

  /// Get a shared pointer to the low-level display driver
  /// \return A shared pointer to the display driver
  const std::shared_ptr<DisplayDriver> &display_driver() const { return display_driver_; }

  /// Set the brightness of the backlight
  /// \param brightness The brightness of the backlight as a percentage (0 - 100)
  /// \note This function will only work after initialize_lcd() has been called
  void brightness(float brightness);

  /// Get the brightness of the backlight
  /// \return The brightness of the backlight as a percentage (0 - 100)
  /// \note This function will only work after initialize_lcd() has been called
  float brightness() const;

  /// Get the VRAM 0 pointer (DMA memory used by LVGL)
  /// \return The VRAM 0 pointer
  /// \note This is the memory used by LVGL for rendering
  /// \note This is null unless initialize_display() has been called
  Pixel *vram0() const;

  /// Get the VRAM 1 pointer (DMA memory used by LVGL)
  /// \return The VRAM 1 pointer
  /// \note This is the memory used by LVGL for rendering
  /// \note This is null unless initialize_display() has been called
  Pixel *vram1() const;

  /// Get the frame buffer 0 pointer
  /// \return The frame buffer 0 pointer
  /// \note This memory is designed to be used by the application developer and
  ///       is provided as a convenience. It is not used by the display driver.
  /// \note This is null unless initialize_display() has been called
  uint8_t *frame_buffer0() const;

  /// Get the frame buffer 1 pointer
  /// \return The frame buffer 1 pointer
  /// \note This memory is designed to be used by the application developer and
  ///       is provided as a convenience. It is not used by the display driver.
  /// \note This is null unless initialize_display() has been called
  uint8_t *frame_buffer1() const;

  /// Write command and optional parameters to the LCD
  /// \param command The command to write
  /// \param parameters The command parameters to write
  /// \param user_data User data to pass to the spi transaction callback
  /// \note This method is designed to be used by the display driver
  /// \note This method queues the data to be written to the LCD, only blocking
  ///      if there is an ongoing SPI transaction
  void write_command(uint8_t command, std::span<const uint8_t> parameters, uint32_t user_data);

  /// Write a frame to the LCD
  /// \param x The x coordinate
  /// \param y The y coordinate
  /// \param width The width of the frame, in pixels
  /// \param height The height of the frame, in pixels
  /// \param data The data to write
  /// \note This method queues the data to be written to the LCD, only blocking
  ///      if there is an ongoing SPI transaction
  void write_lcd_frame(const uint16_t x, const uint16_t y, const uint16_t width,
                       const uint16_t height, uint8_t *data);

  /// Write lines to the LCD
  /// \param xs The x start coordinate
  /// \param ys The y start coordinate
  /// \param xe The x end coordinate
  /// \param ye The y end coordinate
  /// \param data The data to write
  /// \param user_data User data to pass to the spi transaction callback
  /// \note This method queues the panel transfer asynchronously and may return
  ///       before the write has completed.
  void write_lcd_lines(int xs, int ys, int xe, int ye, const uint8_t *data, uint32_t user_data);

  /////////////////////////////////////////////////////////////////////////////
  // Audio
  /////////////////////////////////////////////////////////////////////////////

  /// Get the GPIO pin for the mute button (top of the box)
  /// \return The GPIO pin for the mute button
  static constexpr auto get_mute_pin() { return mute_pin; }

  /// Initialize the sound subsystem
  /// \param default_audio_rate The default audio rate
  /// \param task_config The task configuration for the audio task
  /// \return true if the sound subsystem was successfully initialized, false
  ///         otherwise
  bool
  initialize_sound(uint32_t default_audio_rate = 48000,
                   const espp::Task::BaseConfig &task_config = {
                       .name = "audio", .stack_size_bytes = 4096, .priority = 19, .core_id = 1});

  /// Get the audio sample rate
  /// \return The audio sample rate, in Hz
  uint32_t audio_sample_rate() const;

  /// Set the audio sample rate
  /// \param sample_rate The audio sample rate, in Hz
  void audio_sample_rate(uint32_t sample_rate);

  /// Get the audio buffer size
  /// \return The audio buffer size, in bytes
  size_t audio_buffer_size() const;

  /// Mute or unmute the audio
  /// \param mute true to mute the audio, false to unmute the audio
  void mute(bool mute);

  /// Check if the audio is muted
  /// \return true if the audio is muted, false otherwise
  bool is_muted() const;

  /// Set the volume
  /// \param volume The volume in percent (0 - 100)
  void volume(float volume);

  /// Get the volume
  /// \return The volume in percent (0 - 100)
  float volume() const;

  /// Play audio
  /// \param data The audio data to play (16-bit signed interleaved stereo)
  /// \return The number of bytes actually queued (may be less than the data
  ///         size if the internal stream buffer is full)
  /// \note This function is non-blocking and queues the data for the audio
  ///       task to play; to stream data larger than the internal buffer,
  ///       call it repeatedly, advancing by the returned number of bytes
  /// \note Must be called from task context, not from an ISR.
  size_t play_audio(const std::vector<uint8_t> &data);

  /// Play audio
  /// \param data The audio data to play (16-bit signed interleaved stereo)
  /// \param num_bytes The number of bytes to play
  /// \return The number of bytes actually queued (may be less than \p
  ///         num_bytes if the internal stream buffer is full)
  /// \note This function is non-blocking and queues the data for the audio
  ///       task to play; to stream data larger than the internal buffer,
  ///       call it repeatedly, advancing by the returned number of bytes
  /// \note Must be called from task context, not from an ISR.
  size_t play_audio(const uint8_t *data, uint32_t num_bytes);

  /////////////////////////////////////////////////////////////////////////////
  // Microphone
  /////////////////////////////////////////////////////////////////////////////

  /// Alias for the microphone callback, called with recorded audio data
  using microphone_callback_t = std::function<void(const uint8_t *data, size_t num_bytes)>;

  /// Initialize the microphones (the dual microphone array through the
  /// ES7210 ADC, on its own I2S bus) and start delivering audio data to the
  /// provided callback
  /// \param callback The callback to call with recorded audio data: 16-bit
  ///        signed interleaved stereo. The two populated ES7210 microphones are
  ///        delivered as MIC1 (TDM slot 0) on the left channel and MIC3 (TDM
  ///        slot 2) on the right, at \p sample_rate
  /// \param sample_rate The sample rate for the microphones, in Hz. The
  ///        ES7210 is on a separate I2S bus from the speaker amplifier, so
  ///        this is independent of the speaker's sample rate.
  /// \param task_config The configuration for the microphone task
  /// \return true if the microphone was successfully initialized, false
  ///         otherwise
  /// \note The callback runs in the microphone task's context, so the task's
  ///       stack must be large enough for whatever the callback does with
  ///       the audio data
  bool initialize_microphone(const microphone_callback_t &callback, uint32_t sample_rate = 16000,
                             const espp::Task::BaseConfig &task_config = {.name = "microphone",
                                                                          .stack_size_bytes = 4096,
                                                                          .priority = 10,
                                                                          .core_id = 1});

  /// Get the microphone sample rate
  /// \return The microphone sample rate, in Hz
  uint32_t microphone_sample_rate() const;

  /// Set the microphone volume
  /// \param volume The volume as a percentage (0 - 100), mapped onto the
  ///        ES7210 analog microphone gain range (0 dB - +37.5 dB)
  void microphone_volume(float volume);

  /// Get the microphone volume
  /// \return The microphone volume as a percentage (0 - 100)
  float microphone_volume() const;

protected:
  TDeck();
  bool init_spi_bus();
  bool update_gt911();
  void lcd_wait_lines();
  void on_trackball_interrupt(const espp::Interrupt::Event &event);
  bool initialize_i2s(uint32_t default_audio_rate);
  bool audio_task_callback(std::mutex &m, std::condition_variable &cv, bool &task_notified);
  bool microphone_task_callback(std::mutex &m, std::condition_variable &cv, bool &task_notified);

  // common:
  // internal i2c (touchscreen, keyboard)
  static constexpr auto internal_i2c_port = I2C_NUM_0;
  static constexpr auto internal_i2c_clock_speed = 400 * 1000;
  static constexpr gpio_num_t internal_i2c_sda = GPIO_NUM_18;
  static constexpr gpio_num_t internal_i2c_scl = GPIO_NUM_8;

  // peripherals
  static constexpr gpio_num_t peripheral_power_pin_ = GPIO_NUM_10;

  // keyboard
  static constexpr gpio_num_t keyboard_interrupt_io = GPIO_NUM_46; // NOTE: unused by default

  // Audio In (ES7210)
  static constexpr gpio_num_t es7210_mclk_io = GPIO_NUM_48;
  static constexpr gpio_num_t es7210_sclk_io = GPIO_NUM_47;
  static constexpr gpio_num_t es7210_lrck_io = GPIO_NUM_21;
  static constexpr gpio_num_t es7210_sdout_io = GPIO_NUM_14;
  // NOTE: schematic has this pinned out on the es7210, but it doesn't go anywhere
  //
  // static constexpr gpio_num_t es7210_int_io = GPIO_NUM_17;
  static constexpr gpio_num_t dmic_clk_io = GPIO_NUM_17;
  static constexpr auto mic_i2s_port = I2S_NUM_1;

  // Audio Out (MAX98357A)
  static constexpr auto i2s_port = I2S_NUM_0;
  // static constexpr gpio_num_t i2s_mck_io = GPIO_NUM_2;
  static constexpr gpio_num_t i2s_bck_io = GPIO_NUM_7;
  static constexpr gpio_num_t i2s_do_io = GPIO_NUM_6;
  // static constexpr gpio_num_t i2s_di_io = GPIO_NUM_6;
  static constexpr gpio_num_t i2s_ws_io = GPIO_NUM_5;
  static constexpr gpio_num_t mute_pin = GPIO_NUM_1;

  static constexpr int NUM_CHANNELS = 2;
  static constexpr int NUM_BYTES_PER_CHANNEL = 2;
  static constexpr int UPDATE_FREQUENCY = 60;

  static constexpr int calc_audio_buffer_size(int sample_rate) {
    return sample_rate * NUM_CHANNELS * NUM_BYTES_PER_CHANNEL / UPDATE_FREQUENCY;
  }

  // SPI (shared between LCD and uSD card)
  static constexpr gpio_num_t spi_mosi_io = GPIO_NUM_41;
  static constexpr gpio_num_t spi_miso_io = GPIO_NUM_38;
  static constexpr gpio_num_t spi_sclk_io = GPIO_NUM_40;
  static constexpr auto spi_num = SPI2_HOST;

  // LCD
  static constexpr size_t lcd_width_ = 320;
  static constexpr size_t lcd_height_ = 240;
  static constexpr size_t lcd_bytes_per_pixel = 2;
  static constexpr size_t frame_buffer_size = (((lcd_width_)*lcd_bytes_per_pixel) * lcd_height_);
  static constexpr int lcd_clock_speed = 40 * 1000 * 1000;
  static constexpr gpio_num_t lcd_cs_io = GPIO_NUM_12;
  static constexpr gpio_num_t lcd_reset_io = GPIO_NUM_NC;
  static constexpr gpio_num_t lcd_dc_io = GPIO_NUM_11;
  static constexpr bool backlight_value = true;
  static constexpr bool reset_value = false;
  static constexpr bool invert_colors = false;
  static constexpr auto rotation = espp::DisplayRotation::LANDSCAPE;
  static constexpr bool mirror_x = false;
  static constexpr bool mirror_y = false;
  static constexpr bool mirror_portrait = true;
  static constexpr bool swap_xy = false;
  static constexpr gpio_num_t backlight_io = GPIO_NUM_42;

  // touch
  static constexpr bool touch_swap_xy = true;
  static constexpr bool touch_invert_x = false;
  static constexpr bool touch_invert_y = true;
  static constexpr gpio_num_t touch_interrupt = GPIO_NUM_16;

  // trackball
  static constexpr gpio_num_t trackball_up = GPIO_NUM_15;
  static constexpr gpio_num_t trackball_down = GPIO_NUM_3;
  static constexpr gpio_num_t trackball_left = GPIO_NUM_1;
  static constexpr gpio_num_t trackball_right = GPIO_NUM_2;
  static constexpr gpio_num_t trackball_btn = GPIO_NUM_0; // NOTE: this is the boot button

  // uSD card
  static constexpr gpio_num_t sdcard_cs = GPIO_NUM_39;

  // LoRa (HPD16A)
  // NOTE: the reset line (GPIO 17) is shared with the PDM digital-microphone
  //       clock / ES7210 interrupt line. The espp microphone path (the ES7210
  //       array) uses a different set of pins, so the radio and microphone can
  //       be used together; only a PDM microphone (which would drive GPIO 17)
  //       would conflict.
  static constexpr gpio_num_t lora_reset_io = GPIO_NUM_17;
  static constexpr gpio_num_t lora_cs_io = GPIO_NUM_9;
  static constexpr gpio_num_t lora_dio1_io = GPIO_NUM_45;
  static constexpr gpio_num_t lora_busy_io = GPIO_NUM_13;
  static constexpr int lora_spi_clock_speed = 8 * 1000 * 1000;

  // GPS (T-Deck Plus, u-blox MIA-M10Q); these pins go to the Grove
  // connector on the base T-Deck
  static constexpr gpio_num_t gps_tx_io = GPIO_NUM_43;
  static constexpr gpio_num_t gps_rx_io = GPIO_NUM_44;
  static constexpr auto gps_uart_port = UART_NUM_1;

  // TODO: allow core id configuration
  I2c internal_i2c_{{.port = internal_i2c_port,
                     .sda_io_num = internal_i2c_sda,
                     .scl_io_num = internal_i2c_scl,
                     .sda_pullup_en = GPIO_PULLUP_ENABLE,
                     .scl_pullup_en = GPIO_PULLUP_ENABLE}};

  // sdcard
  std::unique_ptr<espp::SdCard> sdcard_;

  espp::Interrupt::PinConfig touch_interrupt_pin_{
      .gpio_num = touch_interrupt,
      .callback =
          [this](const auto &event) {
            if (update_gt911()) {
              if (touch_callback_) {
                touch_callback_(touchpad_data());
              }
            }
          },
      .active_level = espp::Interrupt::ActiveLevel::HIGH,
      .interrupt_type = espp::Interrupt::Type::RISING_EDGE};

  static constexpr auto trackball_interrupt_type = espp::Interrupt::Type::FALLING_EDGE;
  static constexpr auto trackball_filter_type = espp::Interrupt::FilterType::PIN_GLITCH_FILTER;
  espp::Interrupt::PinConfig trackball_up_interrupt_pin{
      .gpio_num = trackball_up,
      .callback = [this](const auto &event) { on_trackball_interrupt(event); },
      .active_level = espp::Interrupt::ActiveLevel::LOW,
      .interrupt_type = trackball_interrupt_type,
      .pullup_enabled = true,
      .filter_type = trackball_filter_type};
  espp::Interrupt::PinConfig trackball_down_interrupt_pin{
      .gpio_num = trackball_down,
      .callback = [this](const auto &event) { on_trackball_interrupt(event); },
      .active_level = espp::Interrupt::ActiveLevel::LOW,
      .interrupt_type = trackball_interrupt_type,
      .pullup_enabled = true,
      .filter_type = trackball_filter_type};
  espp::Interrupt::PinConfig trackball_left_interrupt_pin{
      .gpio_num = trackball_left,
      .callback = [this](const auto &event) { on_trackball_interrupt(event); },
      .active_level = espp::Interrupt::ActiveLevel::LOW,
      .interrupt_type = trackball_interrupt_type,
      .pullup_enabled = true,
      .filter_type = trackball_filter_type};
  espp::Interrupt::PinConfig trackball_right_interrupt_pin{
      .gpio_num = trackball_right,
      .callback = [this](const auto &event) { on_trackball_interrupt(event); },
      .active_level = espp::Interrupt::ActiveLevel::LOW,
      .interrupt_type = trackball_interrupt_type,
      .pullup_enabled = true,
      .filter_type = trackball_filter_type};
  espp::Interrupt::PinConfig trackball_btn_interrupt_pin{
      .gpio_num = trackball_btn,
      .callback = [this](const auto &event) { on_trackball_interrupt(event); },
      .active_level = espp::Interrupt::ActiveLevel::LOW,
      .interrupt_type = espp::Interrupt::Type::ANY_EDGE,
      .pullup_enabled = true,
      .filter_type = trackball_filter_type};

  // we'll only add each interrupt pin if the initialize method is called
  espp::Interrupt interrupts_{
      {.interrupts = {},
       .event_queue_size = 50,
       .task_config = {.name = "t-deck interrupts",
                       .stack_size_bytes = CONFIG_TDECK_INTERRUPT_STACK_SIZE,
                       .priority = CONFIG_TDECK_INTERRUPT_PRIORITY,
                       .core_id = CONFIG_TDECK_INTERRUPT_CORE_ID}}};

  // keyboard
  std::shared_ptr<I2c::Device<uint8_t>> keyboard_i2c_device_{nullptr};
  std::shared_ptr<TKeyboard> keyboard_{nullptr};

  // trackball
  std::atomic<int> trackball_sensitivity_{10};
  std::shared_ptr<PointerInput> pointer_input_{nullptr};
  std::recursive_mutex trackball_data_mutex_;
  PointerData trackball_data_{};
  trackball_callback_t trackball_callback_{nullptr};

  // touch
  std::shared_ptr<I2c::Device<uint8_t>> touch_i2c_device_;
  std::shared_ptr<Gt911> gt911_;
  std::shared_ptr<TouchpadInput> touchpad_input_;
  std::recursive_mutex touchpad_data_mutex_;
  TouchpadData touchpad_data_;
  touch_callback_t touch_callback_{nullptr};

  // display
  std::shared_ptr<Display<Pixel>> display_;
  std::shared_ptr<DisplayDriver> display_driver_{static_cast<DisplayDriver *>(nullptr)};
  std::vector<Led::ChannelConfig> backlight_channel_configs_{};
  std::shared_ptr<Led> backlight_{};
  static constexpr int spi_queue_size = 6;
  std::unique_ptr<Spi> lcd_spi_;
  std::unique_ptr<SpiPanelIo> lcd_;
  uint8_t *frame_buffer0_{nullptr};
  uint8_t *frame_buffer1_{nullptr};

  // sound
  std::atomic<bool> sound_initialized_{false};
  std::atomic<float> volume_{50.0f};
  std::atomic<bool> mute_{false};
  std::unique_ptr<espp::Task> audio_task_{nullptr};
  // i2s / low-level audio
  i2s_chan_handle_t audio_tx_handle{nullptr};
  std::vector<uint8_t> audio_tx_buffer;
  StreamBufferHandle_t audio_tx_stream;
  i2s_std_config_t audio_std_cfg;

  // LoRa radio
  std::shared_ptr<Spi::Device> lora_spi_device_;
  std::shared_ptr<Sx126x> lora_;
  espp::Interrupt::PinConfig lora_dio1_interrupt_pin_{
      .gpio_num = lora_dio1_io,
      .callback =
          [this](const auto &event) {
            if (lora_) {
              std::error_code ec;
              lora_->handle_dio1_interrupt(ec);
            }
          },
      .active_level = espp::Interrupt::ActiveLevel::HIGH,
      .interrupt_type = espp::Interrupt::Type::RISING_EDGE};

  // GPS
  std::shared_ptr<Gps> gps_;

  // microphone (ES7210 on its own I2S bus)
  std::shared_ptr<I2c::Device<uint8_t>> es7210_i2c_device_;
  std::atomic<bool> microphone_initialized_{false};
  microphone_callback_t microphone_callback_{nullptr};
  std::unique_ptr<espp::Task> microphone_task_{nullptr};
  i2s_chan_handle_t audio_rx_handle{nullptr};
  std::vector<uint8_t> audio_rx_buffer;
  std::atomic<uint32_t> mic_sample_rate_{0};
  // microphone volume (percent), mapped onto the ES7210 analog gain range
  std::atomic<float> mic_volume_{70.0f};
}; // class TDeck
} // namespace espp
